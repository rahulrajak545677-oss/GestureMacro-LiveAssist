package com.gesturemacro.app;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.StateListDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;

/** Small toolkit that builds the dark, grouped "settings" look used on every screen. */
public final class Ui {
    private Ui() {}

    public static final int BG = 0xFF000000;
    public static final int CARD = 0xFF1C1C1E;
    public static final int SEP = 0xFF38383A;
    public static final int TEXT = 0xFFFFFFFF;
    public static final int SUB = 0xFF8E8E93;
    public static final int BLUE = 0xFF0A84FF;
    public static final int GREEN = 0xFF30D158;
    public static final int RED = 0xFFFF453A;

    public interface OnBool { void on(boolean v); }
    public interface OnInt { void on(int v); }

    public static class Page {
        public LinearLayout root;
        public ScrollView scroll;
        public LinearLayout body;
    }

    public static int dp(Context c, float v) {
        return Math.round(v * c.getResources().getDisplayMetrics().density);
    }

    public static TextView tv(Context c, String s, float sp, int color) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        return t;
    }

    public static GradientDrawable round(int color, float radiusPx) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(radiusPx);
        return g;
    }

    private static StateListDrawable pressBg() {
        StateListDrawable s = new StateListDrawable();
        s.addState(new int[]{android.R.attr.state_pressed}, new ColorDrawable(0xFF2C2C2E));
        s.addState(new int[]{}, new ColorDrawable(Color.TRANSPARENT));
        return s;
    }

    // ------------------------------------------------------------------ page chrome

    public static View navBar(Context c, String back, String title, String right,
                              final Runnable onBack, final Runnable onRight) {
        FrameLayout f = new FrameLayout(c);
        TextView t = tv(c, title, 17, TEXT);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        f.addView(t, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER));

        TextView l = tv(c, "‹ " + back, 17, BLUE);
        l.setPadding(dp(c, 12), dp(c, 12), dp(c, 12), dp(c, 12));
        l.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (onBack != null) onBack.run();
            }
        });
        f.addView(l, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.START | Gravity.CENTER_VERTICAL));

        if (right != null) {
            TextView r = tv(c, right, 17, BLUE);
            r.setPadding(dp(c, 16), dp(c, 12), dp(c, 16), dp(c, 12));
            r.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (onRight != null) onRight.run();
                }
            });
            f.addView(r, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                    Gravity.END | Gravity.CENTER_VERTICAL));
        }
        return f;
    }

    public static Page page(Context c, String back, String title, String right,
                            Runnable onBack, Runnable onRight) {
        Page p = new Page();
        LinearLayout root = new LinearLayout(c);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);
        root.setFocusableInTouchMode(true);
        root.addView(navBar(c, back, title, right, onBack, onRight),
                new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(c, 48)));

        ScrollView sv = new ScrollView(c);
        sv.setVerticalScrollBarEnabled(false);
        LinearLayout body = new LinearLayout(c);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(0, dp(c, 8), 0, dp(c, 48));
        sv.addView(body, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        root.addView(sv, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        p.root = root;
        p.scroll = sv;
        p.body = body;
        return p;
    }

    // ------------------------------------------------------------------ groups, headers, footers

    public static LinearLayout group(Context c) {
        LinearLayout g = new LinearLayout(c);
        g.setOrientation(LinearLayout.VERTICAL);
        g.setBackground(round(CARD, dp(c, 10)));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(dp(c, 16), 0, dp(c, 16), 0);
        g.setLayoutParams(lp);
        return g;
    }

    public static void addRow(LinearLayout g, View row) {
        Context c = g.getContext();
        if (g.getChildCount() > 0) {
            View s = new View(c);
            s.setBackgroundColor(SEP);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 1);
            lp.setMargins(dp(c, 16), 0, 0, 0);
            g.addView(s, lp);
        }
        g.addView(row, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
    }

    public static View header(Context c, String text) {
        TextView t = tv(c, text.toUpperCase(), 13, SUB);
        t.setPadding(dp(c, 32), dp(c, 24), dp(c, 16), dp(c, 8));
        return t;
    }

    public static View footer(Context c, String text) {
        TextView t = tv(c, text, 13, SUB);
        t.setPadding(dp(c, 32), dp(c, 8), dp(c, 24), dp(c, 8));
        return t;
    }

    public static View link(Context c, String text, final Runnable click) {
        TextView t = tv(c, text, 13, BLUE);
        t.setPadding(dp(c, 32), dp(c, 2), dp(c, 24), dp(c, 8));
        t.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                click.run();
            }
        });
        return t;
    }

    public static View banner(Context c, String text, final Runnable click) {
        TextView t = tv(c, text, 14, 0xFFFFB340);
        t.setBackground(round(0xFF3B2F1A, dp(c, 10)));
        t.setPadding(dp(c, 16), dp(c, 14), dp(c, 16), dp(c, 14));
        t.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                click.run();
            }
        });
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(dp(c, 16), dp(c, 8), dp(c, 16), dp(c, 8));
        t.setLayoutParams(lp);
        return t;
    }

    // ------------------------------------------------------------------ rows

    private static LinearLayout rowBase(Context c, final Runnable click) {
        LinearLayout r = new LinearLayout(c);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setPadding(dp(c, 16), dp(c, 11), dp(c, 16), dp(c, 11));
        r.setMinimumHeight(dp(c, 46));
        if (click != null) {
            r.setClickable(true);
            r.setBackground(pressBg());
            r.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    click.run();
                }
            });
        }
        return r;
    }

    public static View navRow(Context c, String title, String value, Runnable click, boolean enabled) {
        LinearLayout r = rowBase(c, enabled ? click : null);
        TextView t = tv(c, title, 17, enabled ? TEXT : 0xFF5A5A5E);
        r.addView(t, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        if (value != null && value.length() > 0) {
            TextView v = tv(c, value, 17, SUB);
            v.setPadding(0, 0, dp(c, 8), 0);
            r.addView(v);
        }
        r.addView(tv(c, "›", 24, enabled ? 0xFF636366 : 0xFF3A3A3C));
        return r;
    }

    public static View navRow(Context c, String title, String value, Runnable click) {
        return navRow(c, title, value, click, true);
    }

    public static View textRow(Context c, String title, Runnable click) {
        LinearLayout r = rowBase(c, click);
        r.addView(tv(c, title, 17, TEXT), new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        return r;
    }

    public static View checkRow(Context c, String title, boolean selected, Runnable click) {
        LinearLayout r = rowBase(c, click);
        r.addView(tv(c, title, 17, TEXT), new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        if (selected) r.addView(tv(c, "✓", 20, BLUE));
        return r;
    }

    public static Switch makeSwitch(Context c, boolean checked, final OnBool cb) {
        Switch sw = new Switch(c);
        sw.setChecked(checked);
        int[][] states = {{android.R.attr.state_checked}, {-android.R.attr.state_checked}};
        sw.setTrackTintList(new ColorStateList(states, new int[]{GREEN, 0xFF39393D}));
        sw.setThumbTintList(ColorStateList.valueOf(Color.WHITE));
        sw.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton b, boolean isChecked) {
                if (cb != null) cb.on(isChecked);
            }
        });
        return sw;
    }

    public static View switchRow(Context c, String title, boolean checked, OnBool cb) {
        LinearLayout r = rowBase(c, null);
        r.addView(tv(c, title, 17, TEXT), new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        r.addView(makeSwitch(c, checked, cb));
        return r;
    }

    public static SeekBar makeSeek(Context c, int min, int max, int value, final OnInt cb) {
        SeekBar sb = new SeekBar(c);
        sb.setMax(max - min);
        sb.setProgress(value - min);
        sb.setProgressTintList(ColorStateList.valueOf(BLUE));
        sb.setThumbTintList(ColorStateList.valueOf(Color.WHITE));
        sb.setProgressBackgroundTintList(ColorStateList.valueOf(0xFF48484A));
        final int offset = min;
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (cb != null) cb.on(progress + offset);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
            }
        });
        return sb;
    }

    /** Slider with a turtle on the left and a hare on the right (Initial Delay, Tracking Sensitivity...). */
    public static View sliderRow(Context c, int min, int max, int value, OnInt cb) {
        LinearLayout r = rowBase(c, null);
        r.addView(tv(c, "🐢", 16, TEXT));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        lp.setMargins(dp(c, 8), 0, dp(c, 8), 0);
        r.addView(makeSeek(c, min, max, value, cb), lp);
        r.addView(tv(c, "🐇", 16, TEXT));
        return r;
    }

    public static LinearLayout plainRow(Context c) {
        return rowBase(c, null);
    }
}
