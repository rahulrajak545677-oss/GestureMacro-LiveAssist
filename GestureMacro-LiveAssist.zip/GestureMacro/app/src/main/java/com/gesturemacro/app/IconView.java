package com.gesturemacro.app;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.DashPathEffect;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.view.View;

/** All menu icons are drawn in code on a 0..1 square, so no image files are needed. */
public class IconView extends View {
    public static final int STAR = 0, BELL = 1, DEVICE = 2, GESTURES = 3, HOME = 4, TOGGLES = 5,
            PINCH = 6, LONGPRESS = 7, DOUBLETAP = 8, HOLDDRAG = 9, BACK = 10, PLUS = 11,
            UP = 12, DOWN = 13, LEFT = 14, RIGHT = 15, ZOOMIN = 16, ZOOMOUT = 17, LOCK = 18,
            VOLUP = 19, VOLDOWN = 20, MUTE = 21, SCREENSHOT = 22, POWER = 23, RECENTS = 24;

    private static final int DARK = 0xFF1F1D1B;

    private final int type;
    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint fillStroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint dashed = new Paint(Paint.ANTI_ALIAS_FLAG);

    public IconView(Context c, int type) {
        super(c);
        this.type = type;
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setColor(0xFFFFFFFF);
        stroke.setStrokeWidth(0.06f);
        stroke.setStrokeCap(Paint.Cap.ROUND);
        stroke.setStrokeJoin(Paint.Join.ROUND);
        fill.setStyle(Paint.Style.FILL);
        fill.setColor(0xFFFFFFFF);
        fillStroke.setStyle(Paint.Style.FILL_AND_STROKE);
        fillStroke.setColor(0xFFFFFFFF);
        fillStroke.setStrokeWidth(0.05f);
        fillStroke.setStrokeJoin(Paint.Join.ROUND);
        dashed.setStyle(Paint.Style.STROKE);
        dashed.setColor(0xFFFFFFFF);
        dashed.setStrokeWidth(0.055f);
        dashed.setPathEffect(new DashPathEffect(new float[]{0.09f, 0.06f}, 0f));
    }

    private void arrow(Canvas c, float x1, float y1, float x2, float y2) {
        c.drawLine(x1, y1, x2, y2, stroke);
        double a = Math.atan2(y2 - y1, x2 - x1);
        float len = 0.2f;
        for (int k = -1; k <= 1; k += 2) {
            double b = a + Math.PI - k * Math.toRadians(40);
            c.drawLine(x2, y2, x2 + (float) Math.cos(b) * len, y2 + (float) Math.sin(b) * len, stroke);
        }
    }

    private Path speaker() {
        Path sp = new Path();
        sp.moveTo(0.12f, 0.40f);
        sp.lineTo(0.28f, 0.40f);
        sp.lineTo(0.48f, 0.22f);
        sp.lineTo(0.48f, 0.78f);
        sp.lineTo(0.28f, 0.60f);
        sp.lineTo(0.12f, 0.60f);
        sp.close();
        return sp;
    }

    @Override
    protected void onDraw(Canvas c) {
        float s = Math.min(getWidth(), getHeight());
        c.save();
        c.translate((getWidth() - s) / 2f, (getHeight() - s) / 2f);
        c.scale(s, s);
        switch (type) {
            case STAR: {
                Path sp = new Path();
                for (int i = 0; i < 10; i++) {
                    double a = Math.toRadians(-90 + i * 36);
                    float r = (i % 2 == 0) ? 0.42f : 0.18f;
                    float x = 0.5f + (float) Math.cos(a) * r;
                    float y = 0.54f + (float) Math.sin(a) * r;
                    if (i == 0) sp.moveTo(x, y); else sp.lineTo(x, y);
                }
                sp.close();
                c.drawPath(sp, fillStroke);
                break;
            }
            case BELL: {
                Path b = new Path();
                b.moveTo(0.20f, 0.70f);
                b.cubicTo(0.30f, 0.62f, 0.30f, 0.52f, 0.30f, 0.42f);
                b.cubicTo(0.30f, 0.28f, 0.40f, 0.20f, 0.50f, 0.20f);
                b.cubicTo(0.60f, 0.20f, 0.70f, 0.28f, 0.70f, 0.42f);
                b.cubicTo(0.70f, 0.52f, 0.70f, 0.62f, 0.80f, 0.70f);
                b.close();
                c.drawPath(b, fillStroke);
                c.drawCircle(0.5f, 0.82f, 0.07f, fill);
                c.drawCircle(0.5f, 0.15f, 0.035f, fill);
                break;
            }
            case DEVICE:
                c.drawRoundRect(0.30f, 0.10f, 0.70f, 0.90f, 0.08f, 0.08f, stroke);
                c.drawLine(0.45f, 0.20f, 0.55f, 0.20f, stroke);
                break;
            case GESTURES:
                c.drawCircle(0.5f, 0.5f, 0.38f, stroke);
                c.drawCircle(0.5f, 0.5f, 0.17f, fill);
                break;
            case HOME:
                c.drawCircle(0.5f, 0.5f, 0.34f, stroke);
                c.drawCircle(0.5f, 0.5f, 0.21f, fill);
                break;
            case TOGGLES:
                c.drawRoundRect(0.10f, 0.18f, 0.90f, 0.44f, 0.13f, 0.13f, stroke);
                c.drawCircle(0.74f, 0.31f, 0.07f, fill);
                c.drawRoundRect(0.10f, 0.56f, 0.90f, 0.82f, 0.13f, 0.13f, stroke);
                c.drawCircle(0.26f, 0.69f, 0.07f, fill);
                break;
            case PINCH:
                c.drawCircle(0.20f, 0.80f, 0.09f, stroke);
                c.drawCircle(0.80f, 0.20f, 0.09f, stroke);
                c.drawLine(0.28f, 0.72f, 0.72f, 0.28f, stroke);
                c.drawLine(0.72f, 0.28f, 0.58f, 0.29f, stroke);
                c.drawLine(0.72f, 0.28f, 0.71f, 0.42f, stroke);
                c.drawLine(0.28f, 0.72f, 0.42f, 0.71f, stroke);
                c.drawLine(0.28f, 0.72f, 0.29f, 0.58f, stroke);
                break;
            case LONGPRESS:
                c.drawCircle(0.5f, 0.5f, 0.42f, fill);
                fill.setColor(DARK);
                c.drawCircle(0.5f, 0.5f, 0.33f, fill);
                fill.setColor(0xFFFFFFFF);
                c.drawCircle(0.5f, 0.5f, 0.26f, fill);
                fill.setColor(DARK);
                c.drawCircle(0.5f, 0.5f, 0.18f, fill);
                fill.setColor(0xFFFFFFFF);
                c.drawCircle(0.5f, 0.5f, 0.10f, fill);
                break;
            case DOUBLETAP: {
                c.drawCircle(0.5f, 0.5f, 0.19f, stroke);
                c.drawCircle(0.5f, 0.5f, 0.06f, fill);
                RectF o = new RectF(0.07f, 0.07f, 0.93f, 0.93f);
                c.drawArc(o, 145f, 70f, false, stroke);
                c.drawArc(o, -35f, 70f, false, stroke);
                break;
            }
            case HOLDDRAG:
                c.drawCircle(0.20f, 0.80f, 0.11f, stroke);
                c.drawCircle(0.20f, 0.80f, 0.04f, fill);
                c.drawLine(0.28f, 0.72f, 0.68f, 0.32f, stroke);
                c.drawCircle(0.78f, 0.22f, 0.09f, stroke);
                c.drawCircle(0.78f, 0.22f, 0.03f, fill);
                break;
            case BACK:
                stroke.setStrokeWidth(0.07f);
                c.drawLine(0.82f, 0.5f, 0.18f, 0.5f, stroke);
                c.drawLine(0.18f, 0.5f, 0.42f, 0.26f, stroke);
                c.drawLine(0.18f, 0.5f, 0.42f, 0.74f, stroke);
                stroke.setStrokeWidth(0.06f);
                break;
            case PLUS:
                c.drawRoundRect(0.10f, 0.10f, 0.90f, 0.90f, 0.12f, 0.12f, dashed);
                c.drawLine(0.5f, 0.28f, 0.5f, 0.72f, stroke);
                c.drawLine(0.28f, 0.5f, 0.72f, 0.5f, stroke);
                break;
            case UP:
                arrow(c, 0.5f, 0.85f, 0.5f, 0.15f);
                break;
            case DOWN:
                arrow(c, 0.5f, 0.15f, 0.5f, 0.85f);
                break;
            case LEFT:
                arrow(c, 0.85f, 0.5f, 0.15f, 0.5f);
                break;
            case RIGHT:
                arrow(c, 0.15f, 0.5f, 0.85f, 0.5f);
                break;
            case ZOOMIN:
            case ZOOMOUT:
                c.drawCircle(0.44f, 0.44f, 0.28f, stroke);
                c.drawLine(0.64f, 0.64f, 0.88f, 0.88f, stroke);
                c.drawLine(0.32f, 0.44f, 0.56f, 0.44f, stroke);
                if (type == ZOOMIN) c.drawLine(0.44f, 0.32f, 0.44f, 0.56f, stroke);
                break;
            case LOCK:
                c.drawRoundRect(0.26f, 0.46f, 0.74f, 0.86f, 0.06f, 0.06f, fill);
                c.drawArc(new RectF(0.34f, 0.14f, 0.66f, 0.62f), 180f, 180f, false, stroke);
                break;
            case VOLUP:
            case VOLDOWN:
            case MUTE: {
                c.drawPath(speaker(), fillStroke);
                if (type == MUTE) {
                    c.drawLine(0.62f, 0.38f, 0.88f, 0.62f, stroke);
                    c.drawLine(0.88f, 0.38f, 0.62f, 0.62f, stroke);
                } else {
                    c.drawArc(new RectF(0.38f, 0.34f, 0.74f, 0.66f), -50f, 100f, false, stroke);
                    if (type == VOLUP) c.drawArc(new RectF(0.40f, 0.20f, 0.92f, 0.80f), -50f, 100f, false, stroke);
                }
                break;
            }
            case SCREENSHOT:
                c.drawRoundRect(0.14f, 0.14f, 0.86f, 0.86f, 0.08f, 0.08f, dashed);
                c.drawCircle(0.5f, 0.5f, 0.12f, fill);
                break;
            case POWER:
                c.drawArc(new RectF(0.20f, 0.22f, 0.80f, 0.82f), -60f, 300f, false, stroke);
                c.drawLine(0.5f, 0.12f, 0.5f, 0.50f, stroke);
                break;
            case RECENTS:
                c.drawRoundRect(0.18f, 0.30f, 0.62f, 0.84f, 0.06f, 0.06f, stroke);
                c.drawRoundRect(0.38f, 0.16f, 0.82f, 0.70f, 0.06f, 0.06f, stroke);
                break;
            default:
                break;
        }
        c.restore();
    }
}
