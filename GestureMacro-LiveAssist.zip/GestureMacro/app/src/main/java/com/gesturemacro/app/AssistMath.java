package com.gesturemacro.app;

/**
 * The maths behind Live Assist. No Android classes on purpose, so it can be tested on a PC.
 *
 * The saved gesture is only used as a SHAPE (a guide path). The finger decides how far along
 * that shape the touch is: progress = how far the real finger has moved in the guide's direction.
 * No finger movement means no movement here, so nothing can play by itself.
 */
final class AssistMath {
    private final float[] gx;   // guide points, relative to the first point
    private final float[] gy;
    private final float[] cum;  // length of the guide up to each point
    private final float total;  // total length of the guide
    private final float ux;     // unit vector from guide start to guide end
    private final float uy;
    private final float chord;  // straight distance from guide start to guide end
    private final boolean usable;

    private AssistMath(float[] xy, float minChord) {
        int n = xy.length / 2;
        gx = new float[n];
        gy = new float[n];
        cum = new float[n];
        float len = 0f;
        for (int i = 0; i < n; i++) {
            gx[i] = xy[i * 2] - xy[0];
            gy[i] = xy[i * 2 + 1] - xy[1];
            if (i > 0) len += (float) Math.hypot(gx[i] - gx[i - 1], gy[i] - gy[i - 1]);
            cum[i] = len;
        }
        total = len;
        float cx = n > 0 ? gx[n - 1] : 0f;
        float cy = n > 0 ? gy[n - 1] : 0f;
        chord = (float) Math.hypot(cx, cy);
        ux = chord > 0f ? cx / chord : 0f;
        uy = chord > 0f ? cy / chord : 0f;
        usable = n >= 2 && total > 0f && chord >= minChord;
    }

    /** xy = x,y pairs of the guide in screen pixels. minChord = shortest guide that still has a direction. */
    static AssistMath fromPoints(float[] xy, float minChord) {
        return new AssistMath(xy, minChord);
    }

    /** False for a tap-like guide with no direction: then the user's own movement is passed through. */
    boolean usable() {
        return usable;
    }

    float chord() {
        return chord;
    }

    float total() {
        return total;
    }

    private float[] pointAt(float a) {
        int n = gx.length;
        if (a <= 0f) return new float[]{0f, 0f};
        if (a >= total) return new float[]{gx[n - 1], gy[n - 1]};
        for (int i = 0; i + 1 < n; i++) {
            if (a <= cum[i + 1]) {
                float seg = cum[i + 1] - cum[i];
                float k = seg > 0f ? (a - cum[i]) / seg : 0f;
                return new float[]{gx[i] + (gx[i + 1] - gx[i]) * k, gy[i] + (gy[i + 1] - gy[i]) * k};
            }
        }
        return new float[]{gx[n - 1], gy[n - 1]};
    }

    /**
     * dx,dy = how far the real finger has moved since it went down.
     * strength 0 = the touch follows the finger exactly, 1 = the touch follows the guide shape.
     * Returns where the touch should be, relative to where the finger went down.
     */
    float[] offset(float dx, float dy, float strength) {
        if (!usable) return new float[]{dx, dy};
        float k = Math.max(0f, Math.min(1f, strength));
        float along = dx * ux + dy * uy;
        float s = Math.max(0f, Math.min(1f, along / chord));
        float[] g = pointAt(s * total);
        return new float[]{dx + (g[0] - dx) * k, dy + (g[1] - dy) * k};
    }

    /** How long one injected segment lasts so the touch moves about as fast as the finger does. */
    static long segmentMs(float segLenPx, float speedPxPerMs) {
        long ms = Math.round(segLenPx / Math.max(speedPxPerMs, 0.05f));
        return Math.max(12L, Math.min(50L, ms));
    }

    /** Light smoothing of the measured finger speed. */
    static float smooth(float prev, float inst) {
        return prev <= 0f ? inst : prev * 0.6f + inst * 0.4f;
    }
}
