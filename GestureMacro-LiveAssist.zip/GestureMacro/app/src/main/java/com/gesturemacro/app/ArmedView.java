package com.gesturemacro.app;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.view.View;
import android.view.animation.AccelerateDecelerateInterpolator;

/**
 * Step one of playing a gesture: a red circle appears at the start of every touch the gesture
 * contains. When you double-tap the floating button, merge() slides all circles together into a
 * single one (at the point where the gesture starts), and then the gesture is performed.
 * Not touchable, so the app below and the floating button keep working.
 */
public class ArmedView extends View {
    private final Paint ring = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final float[] pts;     // x,y pairs; the first pair is where the merged circle ends up
    private final float radius;
    private float k;               // 0 = spread out, 1 = merged

    public ArmedView(Context c, float[] xy) {
        super(c);
        pts = xy;
        float d = c.getResources().getDisplayMetrics().density;
        radius = 26f * d;
        ring.setStyle(Paint.Style.STROKE);
        ring.setStrokeWidth(4f * d);
        ring.setColor(0xFFFF2D2D);
        fill.setStyle(Paint.Style.FILL);
        fill.setColor(0xFFFF2D2D);
    }

    /** Slides every circle onto the first one, then calls done. */
    public void merge(final Runnable done) {
        ValueAnimator a = ValueAnimator.ofFloat(0f, 1f);
        a.setDuration(420);
        a.setInterpolator(new AccelerateDecelerateInterpolator());
        a.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator va) {
                k = (Float) va.getAnimatedValue();
                invalidate();
            }
        });
        a.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(Animator animation) {
                done.run();
            }
        });
        a.start();
    }

    @Override
    protected void onDraw(Canvas c) {
        float tx = pts[0];
        float ty = pts[1];
        // a slow pulse while the circles wait for the double-tap
        float pulse = k == 0f ? 1f + 0.07f * (float) Math.sin(System.currentTimeMillis() / 180.0) : 1f + 0.12f * (float) Math.sin(Math.PI * k);
        for (int i = 0; i + 1 < pts.length; i += 2) {
            float x = pts[i] + (tx - pts[i]) * k;
            float y = pts[i + 1] + (ty - pts[i + 1]) * k;
            float fade = i == 0 ? 1f : 1f - 0.7f * k;
            ring.setAlpha((int) (255 * fade));
            fill.setAlpha((int) (60 * fade));
            c.drawCircle(x, y, radius * pulse, fill);
            c.drawCircle(x, y, radius * pulse, ring);
            fill.setAlpha((int) (255 * fade));
            c.drawCircle(x, y, radius * 0.16f, fill);
        }
        if (k == 0f) postInvalidateOnAnimation();
    }
}
