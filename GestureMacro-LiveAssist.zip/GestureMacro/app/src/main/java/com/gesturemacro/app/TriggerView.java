package com.gesturemacro.app;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.view.View;

/**
 * The red trigger. It is drawn once, at a fixed spot, and is never repositioned by touches,
 * gestures or the red touch circles. It only changes brightness while a finger is on it.
 */
public class TriggerView extends View {
    private final Paint ring = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final float radius;
    private boolean active;

    public TriggerView(Context c) {
        super(c);
        float d = c.getResources().getDisplayMetrics().density;
        radius = 26f * d;
        ring.setStyle(Paint.Style.STROKE);
        ring.setStrokeWidth(4f * d);
        ring.setColor(0xFFFF2D2D);
        fill.setStyle(Paint.Style.FILL);
        fill.setColor(0xFFFF2D2D);
    }

    public void setActive(boolean on) {
        active = on;
        invalidate();
    }

    @Override
    protected void onDraw(Canvas c) {
        float cx = getWidth() / 2f;
        float cy = getHeight() / 2f;
        fill.setAlpha(active ? 120 : 60);
        c.drawCircle(cx, cy, radius, fill);
        c.drawCircle(cx, cy, radius, ring);
        fill.setAlpha(255);
        c.drawCircle(cx, cy, radius * 0.16f, fill);
    }
}
